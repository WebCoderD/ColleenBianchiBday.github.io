
$('.row > div').on('click', function() {
  $(this).toggleClass('show-description');
});